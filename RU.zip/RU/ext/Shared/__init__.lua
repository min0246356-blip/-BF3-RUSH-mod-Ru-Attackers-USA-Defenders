ResourceManager:RegisterPartitionLoadHandler(
Guid('DAB4F4C8-B769-11DF-841C-D78D51189A7D'),
function(partition)

    local usTeamEntity = partition:FindInstance(
        Guid('6886257C-9744-45E2-9F2E-C515BDF69BCA')
    )

    if usTeamEntity then

        local usTeam = TeamEntityData(usTeamEntity)
        usTeam:MakeWritable()
        usTeam.id = TeamId.Team2

        print("US -> Team2")
    end


    local ruTeamEntity = partition:FindInstance(
        Guid('2CB9027D-19B1-443F-AC4C-13B7BB5A21A1')
    )

    if ruTeamEntity then

        local ruTeam = TeamEntityData(ruTeamEntity)
        ruTeam:MakeWritable()
        ruTeam.id = TeamId.Team1

        print("RU -> Team1")
    end


    print("Swapped team IDs")

end)